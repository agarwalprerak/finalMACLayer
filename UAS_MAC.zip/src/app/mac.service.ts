import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { ProgramsOffered } from "./ProgramsOffered";
import { ProgramsScheduled } from "./ProgramsScheduled";
import { Applicant } from "./Applicant";

@Injectable({
  providedIn: 'root'
})
export class MacService {
  jsonURL = "http://localhost:3000/";
  constructor(private httpClient: HttpClient) { }

  loadProgramsOffered(){
    let programsOfferedDatabase:any[]=[];
    this.httpClient.get<ProgramsOffered[]>(this.jsonURL+"programsOffered").subscribe(response => {
      for(const Program of(response as any)){
        programsOfferedDatabase.push({
          programId:Program.programId,
          programName:Program.programName,
          description:Program.description,
          applicantEligibility:Program.applicantEligibility,
          duration:Program.duration,
          degreeCertificateOffered:Program.degreeCertificateOffered
        });
      }
    });
    return programsOfferedDatabase;
  }

  loadProgramsScheduled(){
    let programsScheduledDatabase:any[]=[];
    this.httpClient.get<ProgramsScheduled[]>(this.jsonURL+"programsScheduled").subscribe(response => {
      for(const Program of(response as any)){
        programsScheduledDatabase.push({
          scheduledProgramId:Program.scheduledProgramId,
          programName:Program.programName,
          location:Program.location,
          startDate:Program.startDate,
          endDate:Program.endDate,
          sessionsPerWeek:Program.sessionsPerWeek
        });
      }
    });
    return programsScheduledDatabase;
  }

  loadApplicants(){
    let applicantDatabase:any[]=[];
    this.httpClient.get<Applicant[]>(this.jsonURL+"applicant").subscribe(response => {
      for(const applicant of(response as any)){
        applicantDatabase.push({
          id:applicant.id,
          applicantId:applicant.applicantId,
          fullName:applicant.fullName,
          dateOfBirth:applicant.dateOfBirth,
          highestQualification:applicant.highestQualification,
          marksObtained:applicant.marksObtained,
          goals:applicant.goals,
          emailId:applicant.emailId,
          scheduledProgramId:applicant.scheduledProgramId,
          status:applicant.status,
          dateOfInterview:applicant.dateOfInterview
        });
      }
    });
    return applicantDatabase;
  }

  updateApplicant(id:any,applicant:Applicant){
    this.httpClient.put<Applicant>(this.jsonURL+"applicant/"+id,applicant).subscribe(data => {
      
    });
  }
}
