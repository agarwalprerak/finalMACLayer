export class Applicant{
    id:number;
    applicantId:number;
    fullName:string;
    dateOfBirth:string;
    highestQualification:string;
    marksObtained:string;
    goals:string;
    emailId:string;
    scheduledProgramId:string;
    status:string;
    dateOfInterview:string;

    constructor(id:number,applicantId:number,fullName:string,dateOfBirth:string,highestQualification:string,marksObtained:string,goals:string,emailId:string,scheduledProgramId:string,status:string,dateOfInterview:string) {
        this.id=id;
        this.applicantId=applicantId;
        this.fullName=fullName;
        this.dateOfBirth=dateOfBirth;
        this.highestQualification=highestQualification;
        this.marksObtained=marksObtained;
        this.goals=goals;
        this.emailId=emailId;
        this.scheduledProgramId=scheduledProgramId;
        this.status=status;
        this.dateOfInterview=dateOfInterview;
    }
}