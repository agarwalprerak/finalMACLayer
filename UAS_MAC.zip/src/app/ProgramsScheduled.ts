export class ProgramsScheduled{
    scheduledProgramId:string;
    programName:string;
    location:string;
    startDate:string;
    endDate:string;
    sessionsPerWeek:number;

    constructor(scheduledProgramId:string,programName:string,location:string,startDate:string,endDate:string,sessionsPerWeek:number) {
        this.scheduledProgramId=scheduledProgramId;
        this.programName=programName;
        this.location=location;
        this.startDate=startDate;
        this.endDate=endDate;
        this.sessionsPerWeek=sessionsPerWeek;
    }
}