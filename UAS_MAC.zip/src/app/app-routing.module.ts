import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthComponent } from './auth/auth.component';
import { MacComponent } from './mac/mac.component';
import { ViewCoursesComponent } from './mac/view-courses/view-courses.component';
import { ApplicantsComponent } from './mac/applicants/applicants.component';
import { ViewScheduleComponent } from './mac/view-schedule/view-schedule.component';

import { AuthGuard } from './auth.guard';

const routes: Routes = [
  {path: '', pathMatch: 'full', redirectTo: 'auth'},
  {path: 'auth', component: AuthComponent },
  {path: 'mac', component: MacComponent, canActivate: [AuthGuard],children:[
    {path: 'viewCourses', component: ViewCoursesComponent},
    {path: 'applicants', component: ApplicantsComponent},
    {path: 'viewSchedule/:id', component: ViewScheduleComponent}
  ] }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
