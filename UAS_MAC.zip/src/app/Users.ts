export class Users{
    loginId:string;
    password:string;
    role:string;

    constructor(loginId:string,password:string,role:string) {
        this.loginId=loginId;
        this.password=password;
        this.role=role;  
    }
}