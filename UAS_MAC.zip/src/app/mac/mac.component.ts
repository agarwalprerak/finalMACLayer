import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-mac',
  templateUrl: './mac.component.html',
  styleUrls: ['./mac.component.css']
})
export class MacComponent implements OnInit {

  loginUserName: string;
  constructor(private authService: AuthService, private router: Router) {
    this.loginUserName = this.authService.getUserName();
    this.router.navigate(["/mac/viewCourses"]);
   }

  ngOnInit(): void {

  }

  logout(){
    this.authService.logout();
    this.router.navigateByUrl('/auth');
  }

}
