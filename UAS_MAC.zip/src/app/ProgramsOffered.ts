export class ProgramsOffered{
    programId:number;
    programName:string;
    description:string;
    applicantEligibility:string;
    duration:number;
    degreeCertificateOffered:string;

    constructor(programId:number,programName:string,description:string,applicantEligibility:string,duration:number,degreeCertificateOffered:string) {
        this.programId=programId;
        this.programName=programName;
        this.description=description;
        this.applicantEligibility=applicantEligibility;
        this.duration=duration;
        this.degreeCertificateOffered=degreeCertificateOffered;
    }
}