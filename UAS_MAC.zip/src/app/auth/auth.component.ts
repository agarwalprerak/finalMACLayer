import { Component, OnInit } from '@angular/core';
import { Router } from  '@angular/router';
import { AuthService } from  '../auth.service';
import { HttpClient } from "@angular/common/http";
import { Users } from '../Users';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.css']
})
export class AuthComponent implements OnInit {
  userEmail: string="";
  userPassword: string="";
  loginCheck:number=0;

  constructor(private authService: AuthService, private router: Router, private httpClient: HttpClient) { }
  ngOnInit() {  }

  signIn(){
    this.loginCheck = 0;
    this.httpClient.get<Users[]>("http://localhost:3000/users").subscribe(response => {
      for(const user of(response as any)){
        if(user.loginId == this.userEmail && user.password == this.userPassword && user.role == "mac"){
          this.authService.signIn(this.userEmail);
          this.loginCheck = 1;
          this.router.navigateByUrl('/mac');
        }
      }
    });
    if(this.loginCheck == 0){
      ((document.getElementById("loginError") as HTMLInputElement).innerHTML) = "Wrong Combination of Username and Password";
    }
  } 
}