import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthComponent } from './auth/auth.component';
import { MacComponent } from './mac/mac.component';
import { ViewCoursesComponent } from './mac/view-courses/view-courses.component';
import { ApplicantsComponent } from './mac/applicants/applicants.component';
import { ViewScheduleComponent } from './mac/view-schedule/view-schedule.component';

@NgModule({
  declarations: [
    AppComponent,
    AuthComponent,
    MacComponent,
    ViewCoursesComponent,
    ApplicantsComponent,
    ViewScheduleComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
